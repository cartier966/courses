# Lessons 11–13 Live Embeddings Project

This project ties together:

- Lesson 11: Embeddings and semantic similarity
- Lesson 12: Multimodal AI and shared vector-space thinking
- Lesson 13: OpenAI API + ChromaDB + Streamlit semantic search

## Files

- `lesson11_13_live_embeddings_interactive_notebook.ipynb`
- `app.py`
- `requirements.txt`
- `.streamlit/secrets.toml.example`

## Setup

Install dependencies:

```bash
pip install -r requirements.txt
```

Create your secrets file:

```bash
mkdir -p .streamlit
cp .streamlit/secrets.toml.example .streamlit/secrets.toml
```

Edit `.streamlit/secrets.toml`:

```toml
OPENAI_API_KEY = "your_key_here"
```

Run the app:

```bash
streamlit run app.py
```

## Teaching Flow

1. Start with the notebook.
2. Generate a live vector.
3. Compare semantic similarity.
4. Show how model selection affects vector size.
5. Build records and embeddings.
6. Store records in ChromaDB.
7. Open the Streamlit app.
8. Upsert records.
9. Search with non-exact terms like:
   - `feline`
   - `winter morning`
   - `construction machine`
   - `bird with long legs`
   - `warm drink`

## Security

Never commit `.streamlit/secrets.toml`.

Use `.streamlit/secrets.toml.example` as the shareable template.
